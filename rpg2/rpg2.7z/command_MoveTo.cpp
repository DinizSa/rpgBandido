#include "command_MoveTo.h"

cCommand_MoveTo::cCommand_MoveTo(Dynamic* dynamic, float x, float y) {
	this->dynamic = dynamic;
	m_fTargetPosX = x;
	m_fTargetPosY = y;	
	bCompleted = false;
}
cCommand_MoveTo::~cCommand_MoveTo() {

}

void cCommand_MoveTo::Start() {
	this->m_fStartPosX = dynamic->getPosX();
	this->m_fStartPosY = dynamic->getPosY();
	bStarted = true;

	m_fTotalDistance = sqrt((m_fTargetPosX - m_fStartPosX) * (m_fTargetPosX - m_fStartPosX) + (m_fTargetPosY - m_fStartPosY) + (m_fTargetPosY - m_fStartPosY));
	m_fVx = dynamic->getMaxSpeed() * ((m_fTargetPosX - m_fStartPosX) / m_fTotalDistance);
	m_fVy = dynamic->getMaxSpeed() * ((m_fTargetPosY - m_fStartPosY) / m_fTotalDistance);

}

void cCommand_MoveTo::Update(int iElapsedTime) {

	if (dynamic->getPosX() - m_fTargetPosX < 0.5f && dynamic->getPosY() - m_fTargetPosY < 0.5f) {
		dynamic->resetVelocity();
		this->bCompleted = true;

		
	}
	else {
		dynamic->addVelocityX(m_fVx);
		dynamic->addVelocityY(m_fVy);
	}


}