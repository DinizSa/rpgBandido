#include "dynamic.h"

Dynamic::Dynamic():
	Entity(){
	solidVsSolid = false;
	solidVsDynamic = false;
	friendly = true;
	this->vx = 0;
	this->vy = 0;
}
Dynamic::~Dynamic() {
}
Dynamic::Dynamic(string name, float px, float py, float vx, float vy, float width, float height, bool solidVsSolid, bool solidVsDynamic, bool friendly) :
	Entity(name, px, py, width, height)	{
	this->solidVsSolid = solidVsSolid;
	this->solidVsDynamic = solidVsDynamic;
	this->friendly = friendly;
	this->vx = vx;
	this->vy = vy;
}
void Dynamic::move() {
	px += vx;
	py += vy;
}

// Return a pointer to the entity that is colliding or nullptr if not colliding
Entity* Dynamic::getCollidingEntity(vector<Entity>* entitys) {
	for (Entity entity : *entitys)
	{
		if (this->getPosX() + this->getWidth() > entity.getPosX() && this->getPosX() < entity.getPosX() + entity.getWidth()) {
			if (this->getPosY() + this->getWidth() > entity.getPosY() && this->getPosY() < entity.getPosY() + entity.getHeight()) {
				cout << this->getName() << " colliding with " << entity.getName() << endl;
				return &entity;
			}
		}
	}
	return nullptr;
}

// Return a pointer to the entity that is colliding or a nullptr if not colliding, in a chosen direction
// UP: 1, RIGHT: 2, DOWN:3, LEFT: 4
Entity* Dynamic::getCollidingEntity(vector<Entity>*, int direction) {
	
	return nullptr;
}