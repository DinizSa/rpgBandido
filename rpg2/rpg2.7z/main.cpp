#include <SFML/Graphics.hpp>
#include "assets.h"
#include "entity.h"
#include "maps.h"

int main()
{
    sf::RenderWindow window(sf::VideoMode(800, 600), "Window");

    Assets::get().LoadTextures();
    Maps mapOne("map1.txt", "Town1", window.getSize().x, window.getSize().y);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear(sf::Color(0,0,0,255));
        mapOne.draw(&window);
        window.display();
    }

    return 0;
}