#include "maps.h"
#include "assets.h"
#include <iostream>
#include <fstream>

Maps::Maps(string pathToMap, string spriteAsset, int bgWidth, int bgHeight) {

	// Read map and settings from file and construct an array of landscapes
	ifstream data(pathToMap, ios::in | ios::binary);
	if (data.is_open()) {
		int spriteDimX, spriteDimY, spriteNrX, spriteNrY;
		data >> spriteAsset >> nrHorizontal >> nrVertical >> spriteDimX >> spriteDimY >> spriteNrX >> spriteNrY;
		landscapes = new Landscape[nrHorizontal * nrVertical];
		indicesSprite = new int[nrHorizontal * nrVertical];
		solidSprite = new bool[nrHorizontal * nrVertical];

		for (int y = 0; y < nrVertical ; y++)
		{
			for (int x = 0; x < nrHorizontal; x++)
			{
				int ind = x + y * nrHorizontal;
				data >> indicesSprite[ind] >> solidSprite[ind];
				int widthLandscape = bgWidth / nrHorizontal;
				int heightLandscape = bgHeight / nrVertical;
				int widthSpriteInd = spriteDimX / spriteNrX;
				int heightSpriteInd = spriteDimY / spriteNrY;
				landscapes[ind] = Landscape(spriteAsset, x * widthLandscape, y * heightLandscape, widthLandscape, heightLandscape);
				int posSpriteX = ((int)indicesSprite[ind] % spriteNrX) * widthSpriteInd;
				int posSpriteY = floor(indicesSprite[ind] / spriteNrY) * heightSpriteInd;
				landscapes[ind].setPartialTexture(posSpriteX, posSpriteY, widthSpriteInd, heightSpriteInd);
			}
		}
	}
}

Maps::~Maps() {
	delete[] landscapes;
	delete[] indicesSprite;
	delete[] solidSprite;
}

void Maps::draw(sf::RenderWindow* window) {
	for (int i = 0; i < nrHorizontal * nrVertical; i++)
	{
		landscapes[i].Draw(window);
	}
}
