#pragma once
#include "landscape.h"
class Maps {
public:
	Maps(string pathToMap, string spriteAsset, int bgWidth, int bgHeight);
	~Maps();
	void draw(sf::RenderWindow* window);

private:
	Landscape* landscapes;
	int* indicesSprite;
	bool* solidSprite;
	int nrHorizontal, nrVertical;
	string spriteAsset;
};